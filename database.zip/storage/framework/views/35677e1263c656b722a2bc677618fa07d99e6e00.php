<html lang="en">
    <head>
    <title>Bootstrap Form & Table</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script> -->
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
    <style>
        form{
            padding: 15px 20px 15px 20px;
            box-shadow: 0 1px 2.94px 0.06px rgb(4 26 55 / 16%);
            background: linear-gradient(to bottom, #33ccff 0%, #ff99cc 100%);
            border-radius: 2%;
        }
        .card{
            border: none;
        }
        .card-body{
            /* border: 2px solid #61abff; */
            background: linear-gradient(to top right, #33ccff 0%, #ff99cc 100%);
            box-shadow:  linear-gradient(to bottom, #ff99cc 0%, #ff99cc 100%);
        }
        table th{
            background: linear-gradient(to top, #33ccff 0%, #ff99cc 100%);
        }
    </style>
    </head>
    <body>
        <div class="container mt-5">
            <div class="row">
            <div class="col-md-12 col-lg-5">
                <form method="POST" action="<?php echo e(route('kharcha-add')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="select"><strong>Paid By</strong> </label>
                        <select name="paid_by" class="form-control" id="select">
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <option value="<?php echo e($item['id']); ?>"><?php echo e(ucwords($item['name'])); ?></option>                                      
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="amount"><strong>Amount</strong></label>
                        <input name="amount" type="number" class="form-control" id="amount" Placeholder="Amount">
                    </div>
                    <div class="form-group">
                        <label><strong>Divide To</strong></label>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="form-check">
                                <input  name="divide_to[]" class="form-check-input" type="checkbox" value="<?php echo e($item['id']); ?>" id="flexCheckDefault-<?php echo e($a); ?>">
                                <label class="form-check-label" for="flexCheckDefault-<?php echo e($a); ?>">
                                    <?php echo e(ucwords($item['name'])); ?>

                                </label>
                            </div>                           
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <button type="submit" class="btn btn-success">Submit</button>
                </form>
            </div> 
            <div class="col-md-12 col-lg-7">
                <div class="row">     
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>      
                        <div class="card col-md-12 col-lg-6 mt-3">
                            <div class="card-body">
                                <h5 class="card-title"><?php echo e(ucwords($item['name'])); ?>   to</h5>
                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c => $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($i['id'] != $item['id']): ?>                                    
                                        <h6 class="card-subtitle mb-2 text-muted"><?php echo e(ucwords($i['name'])); ?> : <?php echo e($final2[$item['id']][$i['id']]); ?></h6>
                                    <?php endif; ?>                         
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>                                  
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            </div>  
        
        <br>

        <table class="table table-bordered">
        <thead>
            <tr>
                <th>SN</th>
                <th>Paid By</th>
                <th>Divisible To</th>
                <th>Amount</th>
                <th>Per Person</th>
            </tr>
        </thead>
        <tbody>
            <?php
                $total=0;
            ?>
            <?php $__currentLoopData = $expenses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b => $expense): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $total = $total+$expense['amount'];
                ?>
                <tr class="success">
                    <th><?php echo e($b+1); ?></th>
                    <td><?php echo e(ucwords($expense['paid_by'])); ?></td>
                    <td><?php echo e($expense['others']); ?></td>
                    <td><?php echo e($expense['amount']); ?></td>
                    <td><?php echo e($expense['per_person']); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
        </table>
        
        </div>
    </body>
</html><?php /**PATH C:\laragon\www\kharcha\resources\views/expense.blade.php ENDPATH**/ ?>